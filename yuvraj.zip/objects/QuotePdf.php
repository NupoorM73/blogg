<?php


class QuotePdf
{
    /**
     * PDO instance
     * @var PDO 
     */
    private $pdo = null;
 
    private $conn=null;
    private $table_name = "tbl_Quote_Details";
    private $table_name1 = "tbl_Quote_Main";

    public $category;
    public $total_price;
    public $GST;
    public $gross_amount;
    public $timestamp;

    public $active;
    
    
    public function __construct($db){
       //echo $db;
        $this->conn = $db;
       // echo $this->conn;
       
       
       try {
            $this->pdo = new PDO($conStr, self::DB_USER, self::DB_PASSWORD);
            echo "Const";
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    /**
     * fillQuoteDetails is the function to copy  PlainMain and PlantDetails into QuoteMain and QuoteDetails respectived for given plantid and customer
     * */
    
    public function fillQuoteDetails($custid, $plaintid) {
 
        try {
            $this->pdo->beginTransaction();
            
            // Insert values in QuoteMain from PlantMain
                //read from plaint Main
                 try {
                     $query = " select  tbl_Plant_Main.plantid,tbl_Plant_Main.total_price,  tbl_Plant_Main.GST,tbl_Plant_Main.gross_amount             
                         from tbl_Plant_Main
                         where tbl_Plant_Main.plantid = ? 
                         LIMIT 0,1";
     
                         $stmt = $this->conn->prepare( $query );
                         $stmt->bindParam(1, $plaintid);
                         $stmt->execute();
     
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        $this->plantid = $row['plantid'];
                        $this->category = $row['category'];
                        $this->total_price = $row['total_price'];
                        $this->GST = $row['GST'];
                        $this->gross_amount = $row['gross_amount'];
                        
                } catch (PDOException $e) {
                     die($e->getMessage());
                }
                
            
            
              
              
              

            //  Insert values in QuoteDetails from PlantDetails

             
            // commit the transaction
            $this->pdo->commit();
 
            echo 'The amount has been transferred successfully';
 
            return true;
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            die($e->getMessage());
        }
    }
 
    /**
     * close the database connection
     */
    public function __destruct() {
        // close the database connection
        $this->pdo = null;
    }
    
    
    
    
    
    
    function findQuoteID($custid,$plantid)
    {
       // echo "<br> ". $custid;
       // $query = "select users.id, users.name,users.address,users.mobile,users.companyName,tbl_Quote_Main.quoteid,tbl_Quote_Main.custid,tbl_Quote_Main.plantid,tbl_Quote_Main.total_price,tbl_Quote_Main.GST,tbl_Quote_Main.gross_amount,tbl_Quote_Details.quoteid,tbl_Quote_Details.equipment_name,tbl_Quote_Details.technical_specification,tbl_Quote_Details.rate
        //from users,tbl_Quote_Main,tbl_Quote_Details where $custid = tbl_Quote_Main.custid AND tbl_Quote_Main.quoteid = tbl_Quote_Details.quoteid AND $plantid = tbl_Quote_Main.plantid";
        $query = "select tbl_Quote_Main.quoteid
              from users, tbl_Quote_Main, tbl_Quote_Details
              where users.id= ".$custid ." and tbl_Quote_Main.custid=users.id and
              tbl_Quote_Details.`quoteid`=tbl_Quote_Main.`quoteid`
              and plantid= ". $plantid ;
    
    
   //echo $query;
    
        $stmt = $this->conn->prepare( $query );
        
        $stmt->execute();
       // echo  $stmt->rowCount();
        return $stmt;
    }
    function readplantid($custid,$plantid)
    {
       // echo "<br> ". $custid;
       // $query = "select users.id, users.name,users.address,users.mobile,users.companyName,tbl_Quote_Main.quoteid,tbl_Quote_Main.custid,tbl_Quote_Main.plantid,tbl_Quote_Main.total_price,tbl_Quote_Main.GST,tbl_Quote_Main.gross_amount,tbl_Quote_Details.quoteid,tbl_Quote_Details.equipment_name,tbl_Quote_Details.technical_specification,tbl_Quote_Details.rate
        //from users,tbl_Quote_Main,tbl_Quote_Details where $custid = tbl_Quote_Main.custid AND tbl_Quote_Main.quoteid = tbl_Quote_Details.quoteid AND $plantid = tbl_Quote_Main.plantid";
    $query = "select users.id, users.name,users.address,users.mobile,users.companyName,
              tbl_Quote_Main.quoteid,tbl_Quote_Main.custid,tbl_Quote_Main.plantid,tbl_Quote_Main.total_price,
              tbl_Quote_Main.GST,tbl_Quote_Main.gross_amount,
              tbl_Quote_Details.quoteid,tbl_Quote_Details.equipment_name,tbl_Quote_Details.technical_specification,
              tbl_Quote_Details.rate
              from users, tbl_Quote_Main, tbl_Quote_Details
              where users.id= ".$custid ." and tbl_Quote_Main.custid=users.id and
              tbl_Quote_Details.`quoteid`=tbl_Quote_Main.`quoteid`
              and plantid= ". $plantid ;
    
    
   // echo $query;
    
        $stmt = $this->conn->prepare( $query );
        
        $stmt->execute();
       // echo  $stmt->rowCount();
        return $stmt;
    }
    function readAll($from_record_num, $records_per_page){
 
        $query = "SELECT
                    plantid, category, total_price, GST, gross_amount, created, modified
                FROM
                    " . $this->table_name . "
                ORDER BY
                category ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
                   
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
        
        return $stmt;
    } 
    function readOne(){
 
        $query = "SELECT
                    plantid, category, total_price, GST, gross_amount, created, modified
                FROM
                    " . $this->table_name . "
                WHERE
                    plantid = ?
                LIMIT
                    0,1";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->plantid);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->plantid = $row['plantid'];
        $this->category = $row['category'];
        $this->total_price = $row['total_price'];
        $this->GST = $row['GST'];
        $this->gross_amount = $row['gross_amount'];
    }
    
    // used for paging products
    public function countAll(){
 
    $query = "SELECT plantid FROM " . $this->table_name . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    return $num;
        }
        function update(){
 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                category = :category,
                total_price = :total_price,
                GST = :GST,
                gross_amount  = :gross_amount
            WHERE
                plantid = :plantid";
 
    $stmt = $this->conn->prepare($query);
 
    // posted values
    $this->category=htmlspecialchars(strip_tags($this->category));
    $this->total_price=htmlspecialchars(strip_tags($this->total_price));
    $this->GST=htmlspecialchars(strip_tags($this->GST));
    $this->gross_amount=htmlspecialchars(strip_tags($this->gross_amount));
    $this->plantid=htmlspecialchars(strip_tags($this->plantid));
 
    // bind parameters
    $stmt->bindParam(':category', $this->category);
    $stmt->bindParam(':total_price', $this->total_price);
    $stmt->bindParam(':GST', $this->GST);
    $stmt->bindParam(':gross_amount', $this->gross_amount);
    $stmt->bindParam(':plantid', $this->plantid);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}


    function create(){
 
        //write query
       
       
      $query = "INSERT INTO
                    " . $this->table_name . "
               SET
                    category=:category, total_price=:total_price, GST=:GST, gross_amount=:gross_amount, created=:created, modified=:modified, active=:active";
                  
 //echo $query;

 $stmt = $this->conn->prepare($query);
 // posted values
        $this->category=htmlspecialchars(strip_tags($this->category));
        $this->total_price=htmlspecialchars(strip_tags($this->total_price));
        $this->GST=htmlspecialchars(strip_tags($this->GST));
        $this->gross_amount=htmlspecialchars(strip_tags($this->gross_amount));
 
        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
 
        // bind values 
        $stmt->bindParam(":category", $this->category);
        $stmt->bindParam(":total_price", $this->total_price);
        $stmt->bindParam(":GST", $this->GST);
        $stmt->bindParam(":gross_amount", $this->gross_amount);
        $stmt->bindParam(":created", $this->timestamp);
        $stmt->bindParam(":modified", $this->timestamp);
        $stmt->bindParam(":active", $this->active);
 
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
 
    }
    
}



?>
