<?php
// 'user' object
class User{
 
    // database connection and table name
    private $conn;
    private $table_name = "users";
 
    // object properties
    public $id;
    public $name;
    public $address;
    public $pin;
    public $tal;
    public $dist;
    public $state;
    public $companyName;
    public $mobile;
    public $email;
    public $password;
    public $access_level;
    public $access_code;
    public $status;
    public $created;
    public $modified;
 
    // constructor
    public function __construct($db){
        $this->conn = $db;
    }
    // check if given email exist in the database
    function emailExists(){
    
        // query to check if email exists
        $query = "SELECT id, name, access_level, password, status
            FROM " . $this->table_name . "
            WHERE email = ?
            LIMIT 0,1";
 
        // prepare the query
        $stmt = $this->conn->prepare( $query );
 
        // sanitize
        $this->email=htmlspecialchars(strip_tags($this->email));
 
        // bind given email value
        $stmt->bindParam(1, $this->email);
 
        // execute the query
        $stmt->execute();
 
        // get number of rows
        $num = $stmt->rowCount();
 
        // if email exists, assign values to object properties for easy access and use for php sessions
        if($num>0){
 
            // get record details / values
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
            // assign values to object properties
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->access_level = $row['access_level'];
            $this->password = $row['password'];
            $this->status = $row['status'];
 
            // return true because email exists in the database
            return true;
        }
 

        // return false if email does not exist in the database
        return false;
    }

    // create new user record
    function create(){
 
        // to get time stamp for 'created' field
        $this->created=date('Y-m-d H:i:s');
     
        // insert query for user table
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                    name=:name,
                    address=:address,
                    pin=:pin,
                    tal=:tal,
                    dist=:dist,
                    state=:state,
                    companyName=:companyName,
                    mobile=:mobile,
                    email =:email,
                    password =:password,
                    access_level =:access_level,
                    access_code=:access_code,
                    status =:status,
                    created =:created";
     
        // prepare the query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->name=htmlspecialchars(strip_tags($this->name));
        $this->address=htmlspecialchars(strip_tags($this->address));
        $this->pin=htmlspecialchars(strip_tags($this->pin));
        $this->tal=htmlspecialchars(strip_tags($this->tal));
        $this->dist=htmlspecialchars(strip_tags($this->dist));
        $this->state=htmlspecialchars(strip_tags($this->state));
        $this->companyName=htmlspecialchars(strip_tags($this->companyName));
        $this->mobile=htmlspecialchars(strip_tags($this->mobile));
        $this->email=htmlspecialchars(strip_tags($this->email));
        $this->password=htmlspecialchars(strip_tags($this->password));
        $this->access_level=htmlspecialchars(strip_tags($this->access_level));
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
        $this->status=htmlspecialchars(strip_tags($this->status));
     
        // bind the values
        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':pin', $this->pin);
        $stmt->bindParam(':tal', $this->tal);
        $stmt->bindParam(':dist', $this->dist);
        $stmt->bindParam(':state', $this->state);
        $stmt->bindParam(':companyName', $this->companyName);
        $stmt->bindParam(':mobile', $this->mobile);
        $stmt->bindParam(':email', $this->email);
        
       
        // hash the password before saving to database
       // $password_hash = password_hash($this->password, PASSWORD_BCRYPT);
       //$stmt->bindParam(':password', $password_hash);
        $stmt->bindParam(':password', $this->password);
        $stmt->bindParam(':access_level', $this->access_level);
        $stmt->bindParam(':access_code', $this->access_code);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':created', $this->created);
     
        // execute the query, also check if query was successful
        if($stmt->execute()){
            return true;
        }else{
            $this->showError($stmt);
            return false;
        }
     
    }
    
    public function showError($stmt){
        echo "<pre>";
            print_r($stmt->errorInfo());
        echo "</pre>";
    }
    
    // read all user records
    function readAll($from_record_num, $records_per_page){
     
        // query to read all user records, with limit clause for pagination
        $query = "SELECT
                    id,
                    name,
                    address,
                    mobile,
                    email,
                    access_level,
                    created
                FROM " . $this->table_name . "
                ORDER BY id DESC
                LIMIT ?, ?";
     
        // prepare query statement
        $stmt = $this->conn->prepare( $query );
     
        // bind limit clause variables
        $stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
        $stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
     
        // execute query
        $stmt->execute();
     
        // return values
        return $stmt;
    }
    
    // used for paging users
    public function countAll(){
     
        // query to select all user records
        $query = "SELECT id FROM " . $this->table_name . "";
     
        // prepare query statement
        $stmt = $this->conn->prepare($query);
     
        // execute query
        $stmt->execute();
     
        // get number of rows
        $num = $stmt->rowCount();
     
        // return row count
        return $num;
    }
    // used in forgot password feature
    function updateAccessCode(){
     
        // update query
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    access_code = :access_code
                WHERE
                    email = :email";
     
        // prepare the query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
        $this->email=htmlspecialchars(strip_tags($this->email));
     
        // bind the values from the form
        $stmt->bindParam(':access_code', $this->access_code);
        $stmt->bindParam(':email', $this->email);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
    }
    
    // used in forgot password feature
    function updatePassword(){
     
        // update query
        $query = "UPDATE " . $this->table_name . "
                SET password = :password
                WHERE access_code = :access_code";
     
        // prepare the query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->password=htmlspecialchars(strip_tags($this->password));
        $this->access_code=htmlspecialchars(strip_tags($this->access_code));
     
        // bind the values from the form
        $password_hash = password_hash($this->password, PASSWORD_BCRYPT);
        $stmt->bindParam(':password', $password_hash);
        $stmt->bindParam(':access_code', $this->access_code);
     
        // execute the query
        if($stmt->execute()){
            return true;
        }
     
        return false;
    }
    
    
       // read customer by search term
public function search($search_term, $from_record_num, $records_per_page){
 // select query
    $query = "SELECT id, name, address, mobile, email, access_level FROM " . $this->table_name . " where name LIKE ? OR mobile LIKE ? LIMIT ?, ?";
           
 //echo "<br>" .$query;
    // prepare query statement
    $stmt = $this->conn->prepare( $query );
 
    // bind variable values
    $search_term = "%{$search_term}%";
    $stmt->bindParam(1, $search_term);
    $stmt->bindParam(2, $search_term);
    $stmt->bindParam(3, $from_record_num, PDO::PARAM_INT);
   $stmt->bindParam(4, $records_per_page, PDO::PARAM_INT);
 
    // execute query
    $stmt->execute();
// echo "<br>" .$stmt->rowCount();
 
    // return values from database
    return $stmt;
}

public function countAll_BySearch($search_term){
 
    // select query
    $query = "SELECT
                COUNT(*) as total_rows
            FROM
                " . $this->table_name . " p 
            WHERE
                p.name LIKE ? OR p.mobile LIKE ?";
 
 //echo "<br>" .$query;
    // prepare query statement
    $stmt = $this->conn->prepare( $query );
 
    // bind variable values
    $search_term = "%{$search_term}%";
    $stmt->bindParam(1, $search_term);
 
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
    return $row['total_rows'];
}

    
}
?>