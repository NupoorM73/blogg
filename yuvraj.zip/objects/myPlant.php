<?php


class Plant
{
    private $conn;
    private $table_name = "tbl_Plant_Main";
    public $title;
    public $total_price;
    public $GST;
    public $total;
    public $gross_amount;
    public $timestamp;

public $active;
    public function __construct($db){
        $this->conn = $db;
       // echo $this->conn;
    }
    function readAll($from_record_num, $records_per_page){
 
        $query = "SELECT
                    plantid, title, total_price, GST, gross_amount, created, modified
                FROM
                    " . $this->table_name . "
                ORDER BY
                title ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
             
             //echo $query;      
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
        
        return $stmt;
    } 
    
     function read_PlantList($from_record_num, $records_per_page){
 
        $query = "SELECT
                    plantid, title
                FROM
                    " . $this->table_name . "
                ORDER BY
                category ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
                   
                   
                   echo $query;
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
        
        return $stmt;
    } 
    
    
    function readOne(){
 
        $query = "SELECT
                    plantid, title, total_price, GST, gross_amount, created, modified
                FROM
                    " . $this->table_name . "
                WHERE
                    plantid = ?
                LIMIT
                    0,1";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->plantid);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->plantid = $row['plantid'];
        $this->category = $row['category'];
        $this->total_price = $row['total_price'];
        $this->GST = $row['GST'];
        $this->gross_amount = $row['gross_amount'];
    }
    
    // used for paging products
    public function countAll(){
 
    $query = "SELECT plantid FROM " . $this->table_name . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    return $num;
        }
        
        
        
        
        function update(){
 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                title = :category,
                total_price = :total_price,
                GST = :GST,
                gross_amount  = :gross_amount
            WHERE
                plantid = :plantid";
 
    $stmt = $this->conn->prepare($query);
 
    // posted values
    $this->category=htmlspecialchars(strip_tags($this->category));
    $this->total_price=htmlspecialchars(strip_tags($this->total_price));
    $this->GST=htmlspecialchars(strip_tags($this->GST));
    $this->gross_amount=htmlspecialchars(strip_tags($this->gross_amount));
    $this->plantid=htmlspecialchars(strip_tags($this->plantid));
 
    // bind parameters
    $stmt->bindParam(':category', $this->category);
    $stmt->bindParam(':total_price', $this->total_price);
    $stmt->bindParam(':GST', $this->GST);
    $stmt->bindParam(':gross_amount', $this->gross_amount);
    $stmt->bindParam(':plantid', $this->plantid);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}
function delete(){
 
    $query = "DELETE FROM " . $this->table_name . " WHERE plantid = ?";
     
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->plantid);
 
    if($result = $stmt->execute()){
        return true;
    }else{
        return false;
    }
}

    function create(){
 
        //write query
       
       
      $query = "INSERT INTO
                    " . $this->table_name . "
               SET
                    title=:title, total_price=:total_price, GST=:GST, total=:total, gross_amount=:gross_amount, created=:created, modified=:modified, active=:active";
                  
     echo $query;

    $stmt = $this->conn->prepare($query);
    // posted values
        $this->title=htmlspecialchars(strip_tags($this->title));
        $this->total_price=htmlspecialchars(strip_tags($this->total_price));
        $this->GST=htmlspecialchars(strip_tags($this->GST));
         $this->total=htmlspecialchars(strip_tags($this->total));
        $this->gross_amount=htmlspecialchars(strip_tags($this->gross_amount));
 
        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
 
        // bind values 
        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":total_price", $this->total_price);
        $stmt->bindParam(":GST", $this->GST);
        $stmt->bindParam(":Total", $this->total);
        $stmt->bindParam(":gross_amount", $this->gross_amount);
        $stmt->bindParam(":created", $this->timestamp);
        $stmt->bindParam(":modified", $this->timestamp);
        $stmt->bindParam(":active", $this->active);
 
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
 
    }
    
}

//$foo = new Foo($db);
//$funcname = "Variable";
//$foo->create(); // This calls $foo->Variable()

?>