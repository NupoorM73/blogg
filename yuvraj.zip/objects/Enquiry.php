<?php


class Enquiry
{
    private $conn;
    private $table_name = "tbl_enquiry";
    private $table_name1 = "users";
    private $table_name2 ="tbl_Plant_Main";
    public $custid;
    public $cust_name;
    public $mobileno;
    public $plantid;
    
    public $timestamp;

public $active;
    public function __construct($db){
        $this->conn = $db;
       // echo $this->conn;
    }
    
     //check for privious enquiry by same customer for same equipment
    function checkDuplicateEnquiry(){
 

        $query = "SELECT  *  FROM  tbl_enquiry  WHERE custid = ?";
     
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->custid);
 
        
        
                   
       //echo $query;
       
        $stmt->execute();
        
        
        return $stmt;
    } 

    
//read all records    
    function readAll($from_record_num, $records_per_page){
 

        $query = "SELECT
                   " . $this->table_name1 . ".id,  " . $this->table_name1 . ".name, " . $this->table_name1 . ".mobile, " . $this->table_name1 . ".companyName, " . $this->table_name . ".created, " . $this->table_name . ".modified, " .$this->table_name . ".plantid," .$this->table_name2 . ".title
                FROM
                    " . $this->table_name . " , ". $this->table_name1 . ",". $this->table_name2 . "
                WHERE
                " . $this->table_name . ".custid = " . $this->table_name1 . ".id 
                and ". $this->table_name . ".plantid = " . $this->table_name2 . ".plantid
                ORDER BY
                " . $this->table_name1 . ".id ASC
                LIMIT
                    {$from_record_num}, {$records_per_page}";
                   
       //echo $query;
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
        
        
        return $stmt;
    } 
    function readOne(){
 
        $query = "SELECT
                    plantid, category, total_price, GST, gross_amount, created, modified
                FROM
                    " . $this->table_name . "
                WHERE
                    plantid = ?
                LIMIT
                    0,1";
     
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->plantid);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->plantid = $row['plantid'];
        $this->category = $row['category'];
        $this->total_price = $row['total_price'];
        $this->GST = $row['GST'];
        $this->gross_amount = $row['gross_amount'];
    }
    
    // used for paging products
    public function countAll(){
 
    $query = "SELECT custid FROM " . $this->table_name . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    return $num;
        }
        function update(){
 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                category = :category,
                total_price = :total_price,
                GST = :GST,
                gross_amount  = :gross_amount
            WHERE
                plantid = :plantid";
 
    $stmt = $this->conn->prepare($query);
 
    // posted values
    $this->category=htmlspecialchars(strip_tags($this->category));
    $this->total_price=htmlspecialchars(strip_tags($this->total_price));
    $this->GST=htmlspecialchars(strip_tags($this->GST));
    $this->gross_amount=htmlspecialchars(strip_tags($this->gross_amount));
    $this->plantid=htmlspecialchars(strip_tags($this->plantid));
 
    // bind parameters
    $stmt->bindParam(':category', $this->category);
    $stmt->bindParam(':total_price', $this->total_price);
    $stmt->bindParam(':GST', $this->GST);
    $stmt->bindParam(':gross_amount', $this->gross_amount);
    $stmt->bindParam(':plantid', $this->plantid);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}
function delete(){
 
    $query = "DELETE FROM " . $this->table_name . " WHERE plantid = ?";
     
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->plantid);
 
    if($result = $stmt->execute()){
        return true;
    }else{
        return false;
    }
}

    //Insert new enquiry
    
    function create(){
 
        //write query
       
       
      $query = "INSERT INTO
                    " . $this->table_name . "
               SET
                   custid=:custid, plantid=:plantid, status=:status, created=:created, modified=:modified, active=:active";
                  
 //echo $query;

 $stmt = $this->conn->prepare($query);
 // posted values
        $this->custid=htmlspecialchars(strip_tags($this->custid));
        $this->plantid=htmlspecialchars(strip_tags($this->plantid));
        $this->status=htmlspecialchars(strip_tags($this->status));
        $this->active=htmlspecialchars(strip_tags($this->active));
     
        
        //$this->gross_amount=htmlspecialchars(strip_tags($this->gross_amount));
 
        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
 
        // bind values 
        $stmt->bindParam(":custid", $this->custid);
        $stmt->bindParam(":plantid", $this->plantid);
        $stmt->bindParam(":status", $this->status);
        $stmt->bindParam(":created", $this->timestamp);
        $stmt->bindParam(":modified", $this->timestamp);
        $stmt->bindParam(":active", $this->active);
 
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
 
    }
    
    
   
    
}
?>