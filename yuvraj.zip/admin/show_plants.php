<?php
// core configuration
include_once "../config/core.php";

// set page header
// page given in URL parameter, default page is one
$page = isset($_GET['page']) ? $_GET['page'] : 1;
 
// set number of records per page
$records_per_page = 5;
 
// calculate for the query LIMIT clause
$from_record_num = ($records_per_page * $page) - $records_per_page;


// set page title
$page_title="Enquiry";
 
// include login checker
$require_login=true;
include_once "login_checker.php";
 
// include page header HTML
include_once 'layout_head.php';
 
 
 // Contents of this page goes here

  // include database and object files
include_once '../config/database.php';
include_once '../objects/myPlant.php';

 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();
 




$objplant = new Plant($db);

$page_title = "Read Plant";
include_once "layout_header.php";
 
// query products
$stmt = $objplant->readAll($from_record_num, $records_per_page);
 
// specify the page where paging is used
$page_url = "show_plants.php?";
 
// count total rows - used for pagination
$total_rows=$objplant->countAll();
 
// retrieve records here 

echo "<div class='col-md-12'>";
 
  
// read_template.php controls how the product list will be rendered
include_once "read_templateEnquiryCust.php";
 
    
    
echo "</div>";
 
// footer HTML and JavaScript codes
include 'layout_foot.php';
?>