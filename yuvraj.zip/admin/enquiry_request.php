<?php
// core configuration
include_once "../config/core.php";

// set page header
// page given in URL parameter, default page is one
$page = isset($_GET['page']) ? $_GET['page'] : 1;
 
// set number of records per page
$records_per_page = 5;
 
// calculate for the query LIMIT clause
$from_record_num = ($records_per_page * $page) - $records_per_page;


// set page title
$page_title="Insert Enquiry";
 
// include login checker
$require_login=true;
include_once "login_checker.php";
 
// include page header HTML
include_once 'layout_head.php';
 
 
 // Contents of this page goes here

  // include database and object files
include_once '../config/database.php';
include_once '../objects/Enquiry.php';

 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();
 
$objEnquiry = new Enquiry($db);

 
$page_title = "Insert Enquiry";
include_once "layout_header.php";
 


echo "<div class='col-md-12'>";
 
  
 // set product property values
    $objEnquiry->custid = $_GET['custid'];
    $objEnquiry->plantid = $_GET['plantid'];
    
    //echo $objEnquiry->plantid ;
    
    $objEnquiry->status="New";
    $objEnquiry->active=1;
    

    // create the product
    if($objEnquiry->create()){
        echo "<div class='alert alert-success'>Enquiry registred  successfuly. Go to Quotations Tab to send quotation. Thank you!</div>";
    }
 
    // if unable to create the product, tell the user
    else{
        echo "<div class='alert alert-danger'>Unable to Register Enquiry. Please try again.</div>";
    }
 
    
    
echo "</div>";
 
// footer HTML and JavaScript codes
include 'layout_foot.php';
?>