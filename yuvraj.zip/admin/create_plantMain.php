<?php
// core configuration
include_once "../config/core.php";
 
// set page title
$page_title = "Add Plant Main";
 
// include login checker
include_once "login_checker.php";
 
// include classes
include_once '../config/database.php';
include_once '../objects/myPlant.php';
include_once "../libs/php/utils.php";
 
// include page header HTML
include_once "layout_head.php";
 
echo "<div class='col-md-8'>";
 
    // registration form HTML will be here
 // code when form was submitted will be here
 
 // if form was posted
if($_POST){
 
    // get database connection
    $database = new Database();
    $db = $database->getConnection();
 
    // initialize objects
    $plantObj = new Plant($db);
   
 
   
 
    // check if plant already exists
   /* if($user->emailExists()){
        echo "<div class='alert alert-danger'>";
            echo "The email you specified is already registered. Please try again or <a href='{$home_url}login'>login.</a>";
        echo "</div>";
    }
 
    else{*/
        // create user will be here
        // set values to object properties
        $plantObj->title=$_POST['title'];
        
        // create the user
        if($plantObj->create()){
        
            echo "<div class='alert alert-info'>";
                echo "Successfully Added New Plant. ";
            echo "</div>";
        
            // empty posted values
            $_POST=array();
        
        }else{
            echo "<div class='alert alert-danger' role='alert'>Unable to add plant. Please try again.</div>";
        }
     // }
}
?>
<form action='create_plantMain.php' method='post' id='Add Plant Main'>
 
    <table class='table table-responsive'>
 
        <tr>
            <td class='width-30-percent'>Title</td>
            <td><input type='text' name='title' class='form-control' required value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>

      
        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span> ADD Plant
                </button>
            </td>
        </tr>
 
    </table>
</form>
<?php

echo "</div>";
 
// include page footer HTML
include_once "layout_foot.php";
?>