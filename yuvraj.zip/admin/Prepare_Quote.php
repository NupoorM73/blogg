<?php

include('../library/tcpdf.php');
include_once '../config/database.php';
include_once '../objects/QuotePdf.php';
$custid = $_REQUEST['custid'];
$plantid = $_REQUEST['plantid'];

//echo "<br> ". $custid;
    // core configuration
    include_once "../config/core.php";
     
    // check if logged in as admin
    include_once "login_checker.php";
    // set page title
    $page_title = "Quotation";
  
  class XTPDF extends TCPDF
  { 
 
    /* function ColoredTable
     * @param $w array of column widths array(40, 30,70);
     * @param array of header names array("Address", "Comment", "Date")
     * @param array of data array( array( r1col1, r1col2, r1col3), array(r2col1, r2col2, r3col3))
     */
 
 
    public function ColoredTable($w, $header,$data) {
      
        // Colors, line width and bold font
        $this->SetFillColor(255, 0, 0);
        $this->SetTextColor(255);
        $this->SetDrawColor(128, 0, 0);
        $this->SetLineWidth(0.3);
        $this->SetFont('', 'B');
        // Header
  
        $num_headers = count($header);
        for($i = 0; $i < $num_headers; ++$i) {
            $this->Cell($w[$i], 7, $header[$i], 1, 0, 'C', 1);
        }
        $this->Ln();
        // Color and font restoration
        $this->SetFillColor(224, 235, 255);
        $this->SetTextColor(0);
        $this->SetFont('');
        // Data
         
        $fill = 0;
         
        foreach($data as $row) {
             
            $cellcount = array();
            //write text first
            $startX = $this->GetX();
            $startY = $this->GetY();
            //draw cells and record maximum cellcount
            //cell height is 6 and width is 80
     
            foreach ($row as $key => $column):
                 $cellcount[] = $this->MultiCell($w[$key],6,$column,0,'L',$fill,0);
            endforeach;
         
            $this->SetXY($startX,$startY);
  
            //now do borders and fill
            //cell height is 6 times the max number of cells
         
            $maxnocells = max($cellcount);
         
            foreach ($row as $key => $column):
                 $this->MultiCell($w[$key],$maxnocells * 6,'','LR','L',$fill,0);
            endforeach;
     
        $this->Ln();
            // fill equals not fill (flip/flop)
            $fill=!$fill;
             
        }
         
        // draw bottom row border
        $this->Cell(array_sum($w), 0, '', 'T');
    }
  }
  
  
  // get database connection
                $database = new Database();
                $db = $database->getConnection();
           //  echo "Connection Success";
             
                // prepare product object
                $objquotepdf = new QuotePdf($db);
                echo "trace";
                $stmt= $objquotepdf->findQuoteID($_REQUEST['custid'],$_REQUEST['plantid']);
                $quoteid;
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
 
                     echo "trace";
                        extract($row);
                    $quoteid=$row['quoteid'];
                    //echo $quoteid . " Hlo";
                     break;
                }
             
                
    //Prepare file name
    $filename= $quoteid. ".pdf"; 
     echo  $filename;  ;  
    $filelocation = "/home/md4ksanalytics/public_html/quote/pdf/quote/";//windows
    //$filelocation = "/var/www/project/custom/"; //Linux
    // $fileNL = $filelocation.$filename;
     $fileNL = $filelocation.$filename;
    //$fileNL = $filelocation.$filename;//Windows
      // echo $quoteid;
    //$fileNL = $filelocation."/".$filename; //Linux
    $pdf = new XTPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    $pdf->AddPage('P', 'A4');
  
  
    $w=array(16,60,60,10,20,30);   //this is the width of table cells
  
    $header = array('Sr.No.', 'Equipment Name','Technical Specification', 'Qty', 'Price.', 'Amount');
     
    //now preare array of rows
    
    
                 
                $stmt= $objquotepdf->readplantid($_REQUEST['custid'],$_REQUEST['plantid']);
               // echo  $stmt->rowCount();
               
               $data = array();
               
                $srno=1;
                $totalCost;
                $GST;
                $finalCost;
               
                $lastRow;
                 while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
 
                        extract($row);
                        
                        $tableRow=array($srno, $row['equipment_name'],$row['technical_specification'],'1', number_format($row['rate']),number_format($row['rate']));
                        
                        
                        $data[]=$tableRow;
                        $quoteid=$row['tbl_Quote_Main.quoteid'];
                        
                         $totalCost=number_format($row['gross_amount']);
                         $GST = number_format($row['GST']);
                         $grossAmt=number_format($row['total_price']);
                 
                        $srno++;
                        $lastRow=$row;
                 }
                 
                 $data[]=array(' ',' ' ,' ' , '','Total Cost', $grossAmt );
                 
                 $data[]=array('','' ,'' , '','GST', $GST );
                 $data[]=array('','' ,'' , '', 'Final',$totalCost );
                 
                // $data[]=$tableRow;
  
  //Create Quotation Header first
  
  
    $pdf->SetFont('courier','B',14);
    $pdf->Cell(130,5,"Shri Sadguru Agri",0,0);
    $pdf->Cell(59,5,"Quotation",0,1);
   // $pdf->Cell(15,5, $lastRow['quoteid'],0,1);
                            
                            
    $pdf->SetFont('courier','',12);
    $pdf->Cell(130,5,'Address',0,0);
    $pdf->Cell(59,5,'',0,1);
    
    $timestamp = date('d-m-Y');
    
    $pdf->Cell(130,5,'City Country,ZIP',0,0);
    $pdf->Cell(25,5,'Date',0,0);
    $pdf->Cell(34,5,$timestamp,0,1);
                    
    $pdf->Cell(105,5,'mobile no +91 9175358072',0,0);
    $pdf->Cell(25,5,'',0,0);
    //$pdf=$row['quoteid'];
   // $QuotatioNo=
    $pdf->Cell(25,5,"Quotation No:-".$quoteid,0,1);
    
    //space
    $pdf->Cell(189,10,'',0,1);
    $pdf->Cell(100,5,'Quotation to',0,1);
    $pdf->Cell(100,5,'Customer Name',0,1);
                                                   
  
  
  
    
  //Create quotation table  
    $pdf->ColoredTable($w, $header, $data);
    
    //$pdf->Output();
    
    
    $pdf->Output($fileNL, 'F');
   // $pdf->Output('kuitti'.$quoteid.'.pdf', 'F');
    
     include_once "layout_head.php";
    // query products
    echo "<div class='col-md-12'>";
    echo "<br>File Written Successfully ".$fileNL;
    echo "</div>";
    
    // layout_footer.php holds our javascript and closing html tags
    include_once "layout_foot.php";

?>