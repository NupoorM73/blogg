<?php
// core configuration
include_once "../config/core.php";
 
// check if logged in as admin
include_once "login_checker.php";

// page given in URL parameter, default page is one
$page = isset($_GET['page']) ? $_GET['page'] : 1;
 
// set number of records per page
$records_per_page = 5;
 
// calculate for the query LIMIT clause
$from_record_num = ($records_per_page * $page) - $records_per_page;

// retrieve records here
// include database and object files
// include classes
include_once '../config/database.php';
include_once '../objects/myPlant.php';


// get database connection
$database = new Database();
$db = $database->getConnection();
 
$objPlant = new Plant($db);


// set page header
$page_title = "Read Plants";

include_once "layout_head.php";


echo "<div class='col-md-12'>"; 

    // query products
    $stmt = $objPlant->readAll($from_record_num, $records_per_page);
    $num = $stmt->rowCount();
     //echo $num;
    
    $total_rows=$num;
     // count retrieved users
        $num = $stmt->rowCount();
     
        // to identify page for paging
        $page_url="read_plants.php?";
     
        // include products table HTML template
        include_once "read_plants_template.php";
    
    /*
     // display the products if there are any
    if($total_rows>0){
     
        echo "<table class='table table-hover table-responsive table-bordered'>";
            echo "<tr>";
                echo "<th>Customer ID</th>";
                echo "<th>Customer Name</th>";
                echo "<th>Mobile No</th>";
                echo "<th>Plantid</th>";
                echo "<th>Company Name</th>";
            echo "</tr>";
     
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
     
                extract($row);
     
                echo "<tr>";
                    echo "<td>{$id}</td>";
                    echo "<td>{$name}</td>";
                    echo "<td>{$mobile}</td>";
                    echo "<td>{$plantid}</td>";
                    echo "<td>{$companyName}</td>";
     
                    echo "<td>";
     
                        // read product button
                        echo "<a href='Prepare_Quote.php?custid={$id}' class='btn btn-primary left-margin'>";
                            echo "<span class='glyphicon glyphicon-list'></span> Prepare Quote";
                        echo "</a>";
     
                        
     
                    echo "</td>";
     
                echo "</tr>";
     
            }
     
        echo "</table>";
     
        // paging buttons
        include_once 'paging.php';
        
    }
     
    // tell the user there are no products
    else{
        echo "<div class='alert alert-danger'>No products found.</div>";
    }
    */
echo "</div>";

// set page footer
include_once "layout_footer.php";
?>