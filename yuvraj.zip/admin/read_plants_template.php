<?php

// search form
echo "<form role='search' action='search_plants.php'>";
    echo "<div class='input-group col-md-3 pull-left margin-right-1em'>";
        $search_value=isset($search_term) ? "value='{$search_term}'" : "";
        echo "<input type='text' class='form-control' placeholder='Type plant name ...' name='s' id='srch-term' required {$search_value} />";
        echo "<div class='input-group-btn'>";
            echo "<button class='btn btn-primary' type='submit'><i class='glyphicon glyphicon-search'></i></button>";
        echo "</div>";
    echo "</div>";
echo "</form>";

// add Plant button
echo "<div class='right-button-margin'>";
    echo "<a href='create_plantMain.php' class='btn btn-primary pull-right'>";
        echo "<span class='glyphicon glyphicon-plus'></span> Add Plant";
    echo "</a>";
echo "</div>";

if($total_rows>0){
 
 /*echo "<a href='directEnquiryByAdmin.php' class='btn btn-primary left-margin'>";
 echo "<span class='glyphicon '></span> Add Direct Enquiry";
 echo "</a>";*/
    echo "<table class='table table-hover table-responsive table-bordered'>";
        echo "<tr>";
            echo "<th>Plant ID</th>";
            echo "<th>Plant Name</th>";
           
        echo "</tr>";
 
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
 
            extract($row);
 
            echo "<tr>";
                echo "<td>{$plantid}</td>";
                echo "<td>{$title}</td>";
                
 
                echo "<td>";
 
                    // read user button
                    echo "<a href='read_one_Plant.php?id={$plantid}' class='btn btn-primary left-margin'>";
                        echo "<span class='glyphicon glyphicon-list'></span> Read";
                    echo "</a>";
 
                    // edit user button
                    echo "<a href='update_plant.php?id={$plantid}' class='btn btn-info left-margin'>";
                        echo "<span class='glyphicon glyphicon-edit'></span> Edit";
                    echo "</a>";
 
                    // delete user button
                    echo "<a delete-id='{$plantid}' class='btn btn-danger delete-object'>";
                        echo "<span class='glyphicon glyphicon-remove'></span> Delete";
                    echo "</a>";
 
                   
 
                    
 
                echo "</td>";
 
            echo "</tr>";
 
        }
 
    echo "</table>";
 
 $page_url="read_plants.php?";
    $total_rows = $objEnquiry->countAll();
    // paging buttons
    include_once 'paging.php';
}
 
// tell the user there are no products
else{
    echo "<div class='alert alert-danger'>No plants found.</div>";
}
?>